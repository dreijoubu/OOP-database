/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package finalproject;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 *
 * @author Maverick Verdida
 */
public class DataManagements extends javax.swing.JPanel {

    SchoolYear sy = new SchoolYear();
    Semester sem = new Semester();
    College cl = new College();
    Student st = new Student();
    Employee em = new Employee();
    Subject sj = new Subject();
    Course cr = new Course();
    
    SchoolYearAdd sya = new SchoolYearAdd();
    SemesterAdd sma = new SemesterAdd();
    CollegeAdd cla = new CollegeAdd();
    StudentAdd sta = new StudentAdd();
    EmployeeAdd ema = new EmployeeAdd();
    SubjectAdd sja = new SubjectAdd();
    CourseAdd cra = new CourseAdd();
    
    /**
     * Creates new form Home
     */
    public DataManagements() {
        initComponents();
        
        dmTransitionCard.add(sy);
        dmTransitionCard.add(sem);
        dmTransitionCard.add(cl);
        dmTransitionCard.add(st);
        dmTransitionCard.add(em);
        dmTransitionCard.add(sj);
        dmTransitionCard.add(cr);
        
        dmTransitionCard.add(sya);
        dmTransitionCard.add(sma);
        dmTransitionCard.add(cla);
        dmTransitionCard.add(sta);
        dmTransitionCard.add(ema);
        dmTransitionCard.add(sja);
        dmTransitionCard.add(cra);
        
        sy.setVisible(false);
        sem.setVisible(false);
        cl.setVisible(false);
        st.setVisible(false);
        em.setVisible(false);
        sj.setVisible(false);
        cr.setVisible(false);
        
        sya.setVisible(false);
        sma.setVisible(false);
        cla.setVisible(false);
        sta.setVisible(false);
        ema.setVisible(false);
        sja.setVisible(false);
        cra.setVisible(false);
        
        sy.Add.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent me) {
                sya.setVisible(true);
                sy.setVisible(false);
                sma.setVisible(false);
                cla.setVisible(false);
                sta.setVisible(false);
                ema.setVisible(false);
                sja.setVisible(false);
                cra.setVisible(false);
            }
        });
        
        sya.btnBack.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent me) {
                sya.setVisible(false);
                sy.setVisible(true);
                sma.setVisible(false);
                cla.setVisible(false);
                sta.setVisible(false);
                ema.setVisible(false);
                sja.setVisible(false);
                cra.setVisible(false);
            }
        });
        
        sem.Add.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent me) {
                sya.setVisible(false);
                sem.setVisible(false);
                sma.setVisible(true);
                cla.setVisible(false);
                sta.setVisible(false);
                ema.setVisible(false);
                sja.setVisible(false);
                cra.setVisible(false);
            }
        });
        
        sma.btnBack.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent me) {
                sya.setVisible(false);
                sem.setVisible(true);
                sma.setVisible(false);
                cla.setVisible(false);
                sta.setVisible(false);
                ema.setVisible(false);
                sja.setVisible(false);
                cra.setVisible(false);
            }
        });
        
        cl.Add.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent me) {
                sya.setVisible(false);
                cl.setVisible(false);
                sma.setVisible(false);
                cla.setVisible(true);
                sta.setVisible(false);
                ema.setVisible(false);
                sja.setVisible(false);
                cra.setVisible(false);
            }
        });
        
        cla.btnBack.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent me) {
                sya.setVisible(false);
                cl.setVisible(true);
                sma.setVisible(false);
                cla.setVisible(false);
                sta.setVisible(false);
                ema.setVisible(false);
                sja.setVisible(false);
                cra.setVisible(false);
            }
        });
        
        st.Add.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent me) {
                sya.setVisible(false);
                st.setVisible(false);
                sma.setVisible(false);
                cla.setVisible(false);
                sta.setVisible(true);
                ema.setVisible(false);
                sja.setVisible(false);
                cra.setVisible(false);
            }
        });
        
        sta.btnBack.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent me) {
                sya.setVisible(false);
                st.setVisible(true);
                sma.setVisible(false);
                cla.setVisible(false);
                sta.setVisible(false);
                ema.setVisible(false);
                sja.setVisible(false);
                cra.setVisible(false);
            }
        });
        
        em.Add.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent me) {
                sya.setVisible(false);
                em.setVisible(false);
                sma.setVisible(false);
                cla.setVisible(false);
                sta.setVisible(false);
                ema.setVisible(true);
                sja.setVisible(false);
                cra.setVisible(false);
            }
        });
        
        ema.btnBack.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent me) {
                sya.setVisible(false);
                em.setVisible(true);
                sma.setVisible(false);
                cla.setVisible(false);
                sta.setVisible(false);
                ema.setVisible(false);
                sja.setVisible(false);
                cra.setVisible(false);
            }
        });
        
        sj.Add.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent me) {
                sya.setVisible(false);
                sj.setVisible(false);
                sma.setVisible(false);
                cla.setVisible(false);
                sta.setVisible(false);
                ema.setVisible(false);
                sja.setVisible(true);
                cra.setVisible(false);
            }
        });
        
        sja.btnBack.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent me) {
                sya.setVisible(false);
                sj.setVisible(true);
                sma.setVisible(false);
                cla.setVisible(false);
                sta.setVisible(false);
                ema.setVisible(false);
                sja.setVisible(false);
                cra.setVisible(false);
            }
        });
        
        cr.Add.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent me) {
                sya.setVisible(false);
                cr.setVisible(false);
                sma.setVisible(false);
                cla.setVisible(false);
                sta.setVisible(false);
                ema.setVisible(false);
                sja.setVisible(false);
                cra.setVisible(true);
            }
        });
        
        cra.btnBack.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent me) {
                sya.setVisible(false);
                cr.setVisible(true);
                sma.setVisible(false);
                cla.setVisible(false);
                sta.setVisible(false);
                ema.setVisible(false);
                sja.setVisible(false);
                cra.setVisible(false);
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlSchoolYear = new finalproject.RoundedPanel();
        btnSchoolYear = new javax.swing.JLabel();
        pnlSemester = new finalproject.RoundedPanel();
        btnSem = new javax.swing.JLabel();
        pnlCollege = new finalproject.RoundedPanel();
        btnCollege = new javax.swing.JLabel();
        pnlCourse = new finalproject.RoundedPanel();
        btnCourse = new javax.swing.JLabel();
        pnlSubject = new finalproject.RoundedPanel();
        jLabel7 = new javax.swing.JLabel();
        pnlEmployee = new finalproject.RoundedPanel();
        btnEmployee = new javax.swing.JLabel();
        pnlStudent = new finalproject.RoundedPanel();
        btnStudent = new javax.swing.JLabel();
        dmTransitionCard = new javax.swing.JLayeredPane();

        setBackground(new java.awt.Color(255, 255, 255));

        pnlSchoolYear.setBackground(new java.awt.Color(25, 42, 86));

        btnSchoolYear.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        btnSchoolYear.setForeground(new java.awt.Color(255, 255, 255));
        btnSchoolYear.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnSchoolYear.setText("School Year");
        btnSchoolYear.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSchoolYear.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSchoolYearMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnSchoolYearMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnSchoolYearMouseExited(evt);
            }
        });

        javax.swing.GroupLayout pnlSchoolYearLayout = new javax.swing.GroupLayout(pnlSchoolYear);
        pnlSchoolYear.setLayout(pnlSchoolYearLayout);
        pnlSchoolYearLayout.setHorizontalGroup(
            pnlSchoolYearLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSchoolYearLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSchoolYear, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlSchoolYearLayout.setVerticalGroup(
            pnlSchoolYearLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSchoolYearLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSchoolYear, javax.swing.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnlSemester.setBackground(new java.awt.Color(34, 62, 118));

        btnSem.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        btnSem.setForeground(new java.awt.Color(255, 255, 255));
        btnSem.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnSem.setText("Semester");
        btnSem.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSemMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnSemMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnSemMouseExited(evt);
            }
        });

        javax.swing.GroupLayout pnlSemesterLayout = new javax.swing.GroupLayout(pnlSemester);
        pnlSemester.setLayout(pnlSemesterLayout);
        pnlSemesterLayout.setHorizontalGroup(
            pnlSemesterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSemesterLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSem, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlSemesterLayout.setVerticalGroup(
            pnlSemesterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSemesterLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSem, javax.swing.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnlCollege.setBackground(new java.awt.Color(34, 62, 118));

        btnCollege.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        btnCollege.setForeground(new java.awt.Color(255, 255, 255));
        btnCollege.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnCollege.setText("College");
        btnCollege.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCollege.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCollegeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCollegeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnCollegeMouseExited(evt);
            }
        });

        javax.swing.GroupLayout pnlCollegeLayout = new javax.swing.GroupLayout(pnlCollege);
        pnlCollege.setLayout(pnlCollegeLayout);
        pnlCollegeLayout.setHorizontalGroup(
            pnlCollegeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCollegeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnCollege, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlCollegeLayout.setVerticalGroup(
            pnlCollegeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCollegeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnCollege, javax.swing.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnlCourse.setBackground(new java.awt.Color(34, 62, 118));

        btnCourse.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        btnCourse.setForeground(new java.awt.Color(255, 255, 255));
        btnCourse.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnCourse.setText("Course");
        btnCourse.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCourse.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCourseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCourseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnCourseMouseExited(evt);
            }
        });

        javax.swing.GroupLayout pnlCourseLayout = new javax.swing.GroupLayout(pnlCourse);
        pnlCourse.setLayout(pnlCourseLayout);
        pnlCourseLayout.setHorizontalGroup(
            pnlCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCourseLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnCourse, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlCourseLayout.setVerticalGroup(
            pnlCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCourseLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnCourse, javax.swing.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnlSubject.setBackground(new java.awt.Color(34, 62, 118));

        jLabel7.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Subject");
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel7MouseExited(evt);
            }
        });

        javax.swing.GroupLayout pnlSubjectLayout = new javax.swing.GroupLayout(pnlSubject);
        pnlSubject.setLayout(pnlSubjectLayout);
        pnlSubjectLayout.setHorizontalGroup(
            pnlSubjectLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE)
        );
        pnlSubjectLayout.setVerticalGroup(
            pnlSubjectLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSubjectLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnlEmployee.setBackground(new java.awt.Color(34, 62, 118));

        btnEmployee.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        btnEmployee.setForeground(new java.awt.Color(255, 255, 255));
        btnEmployee.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnEmployee.setText("Employee");
        btnEmployee.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEmployee.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEmployeeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnEmployeeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnEmployeeMouseExited(evt);
            }
        });

        javax.swing.GroupLayout pnlEmployeeLayout = new javax.swing.GroupLayout(pnlEmployee);
        pnlEmployee.setLayout(pnlEmployeeLayout);
        pnlEmployeeLayout.setHorizontalGroup(
            pnlEmployeeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlEmployeeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnEmployee, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlEmployeeLayout.setVerticalGroup(
            pnlEmployeeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlEmployeeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnEmployee, javax.swing.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnlStudent.setBackground(new java.awt.Color(34, 62, 118));

        btnStudent.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        btnStudent.setForeground(new java.awt.Color(255, 255, 255));
        btnStudent.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnStudent.setText("Student");
        btnStudent.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnStudent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnStudentMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnStudentMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnStudentMouseExited(evt);
            }
        });

        javax.swing.GroupLayout pnlStudentLayout = new javax.swing.GroupLayout(pnlStudent);
        pnlStudent.setLayout(pnlStudentLayout);
        pnlStudentLayout.setHorizontalGroup(
            pnlStudentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlStudentLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnStudent, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlStudentLayout.setVerticalGroup(
            pnlStudentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlStudentLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnStudent, javax.swing.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
                .addContainerGap())
        );

        dmTransitionCard.setBackground(new java.awt.Color(0, 0, 0));
        dmTransitionCard.setLayout(new java.awt.CardLayout());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dmTransitionCard)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(pnlSchoolYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pnlSemester, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pnlCollege, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pnlCourse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pnlStudent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pnlEmployee, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pnlSubject, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(pnlSubject, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlEmployee, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlStudent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlCourse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlCollege, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlSemester, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlSchoolYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dmTransitionCard, javax.swing.GroupLayout.DEFAULT_SIZE, 660, Short.MAX_VALUE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnSchoolYearMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSchoolYearMouseClicked
        // TODO add your handling code here:
        pnlSchoolYear.setBackground(new Color(25,42,86));
        pnlSemester.setBackground(new Color(34,62,118));
        pnlCollege.setBackground(new Color(34,62,118));
        pnlCourse.setBackground(new Color(34,62,118));
        pnlStudent.setBackground(new Color(34,62,118));
        pnlEmployee.setBackground(new Color(34,62,118));
        pnlSubject.setBackground(new Color(34,62,118));
        sy.setVisible(true);
        sem.setVisible(false);
        cl.setVisible(false);
        st.setVisible(false);
        em.setVisible(false);
        sj.setVisible(false);
        cr.setVisible(false);
    }//GEN-LAST:event_btnSchoolYearMouseClicked

    private void btnSemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSemMouseClicked
        // TODO add your handling code here:
        pnlSemester.setBackground(new Color(25,42,86));
        pnlSchoolYear.setBackground(new Color(34,62,118));
        pnlCollege.setBackground(new Color(34,62,118));
        pnlCourse.setBackground(new Color(34,62,118));
        pnlStudent.setBackground(new Color(34,62,118));
        pnlEmployee.setBackground(new Color(34,62,118));
        pnlSubject.setBackground(new Color(34,62,118));
        sy.setVisible(false);
        sem.setVisible(true);
        cl.setVisible(false);
        st.setVisible(false);
        em.setVisible(false);
        sj.setVisible(false);
        cr.setVisible(false);
    }//GEN-LAST:event_btnSemMouseClicked

    private void btnCollegeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCollegeMouseClicked
        // TODO add your handling code here:
        pnlCollege.setBackground(new Color(25,42,86));
        pnlSchoolYear.setBackground(new Color(34,62,118));
        pnlSemester.setBackground(new Color(34,62,118));
        pnlCourse.setBackground(new Color(34,62,118));
        pnlStudent.setBackground(new Color(34,62,118));
        pnlEmployee.setBackground(new Color(34,62,118));
        pnlSubject.setBackground(new Color(34,62,118));
        sy.setVisible(false);
        sem.setVisible(false);
        cl.setVisible(true);
        st.setVisible(false);
        em.setVisible(false);
        sj.setVisible(false);
        cr.setVisible(false);
    }//GEN-LAST:event_btnCollegeMouseClicked

    private void btnCourseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCourseMouseClicked
        // TODO add your handling code here:
        pnlCourse.setBackground(new Color(25,42,86));
        pnlSchoolYear.setBackground(new Color(34,62,118));
        pnlSemester.setBackground(new Color(34,62,118));
        pnlCollege.setBackground(new Color(34,62,118));
        pnlStudent.setBackground(new Color(34,62,118));
        pnlEmployee.setBackground(new Color(34,62,118));
        pnlSubject.setBackground(new Color(34,62,118));
        sy.setVisible(false);
        sem.setVisible(false);
        cl.setVisible(false);
        st.setVisible(false);
        em.setVisible(false);
        sj.setVisible(false);
        cr.setVisible(true);
    }//GEN-LAST:event_btnCourseMouseClicked

    private void btnStudentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnStudentMouseClicked
        // TODO add your handling code here:
        pnlStudent.setBackground(new Color(25,42,86));
        pnlSchoolYear.setBackground(new Color(34,62,118));
        pnlSemester.setBackground(new Color(34,62,118));
        pnlCollege.setBackground(new Color(34,62,118));
        pnlCourse.setBackground(new Color(34,62,118));
        pnlEmployee.setBackground(new Color(34,62,118));
        pnlSubject.setBackground(new Color(34,62,118));
        sy.setVisible(false);
        sem.setVisible(false);
        cl.setVisible(false);
        st.setVisible(true);
        em.setVisible(false);
        sj.setVisible(false);
        cr.setVisible(false);
    }//GEN-LAST:event_btnStudentMouseClicked

    private void btnEmployeeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEmployeeMouseClicked
        // TODO add your handling code here:
        pnlEmployee.setBackground(new Color(25,42,86));
        pnlSchoolYear.setBackground(new Color(34,62,118));
        pnlSemester.setBackground(new Color(34,62,118));
        pnlCollege.setBackground(new Color(34,62,118));
        pnlCourse.setBackground(new Color(34,62,118));
        pnlStudent.setBackground(new Color(34,62,118));
        pnlSubject.setBackground(new Color(34,62,118));
        sy.setVisible(false);
        sem.setVisible(false);
        cl.setVisible(false);
        st.setVisible(false);
        em.setVisible(true);
        sj.setVisible(false);
        cr.setVisible(false);
    }//GEN-LAST:event_btnEmployeeMouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        // TODO add your handling code here:
        pnlSubject.setBackground(new Color(25,42,86));
        pnlSchoolYear.setBackground(new Color(34,62,118));
        pnlSemester.setBackground(new Color(34,62,118));
        pnlCollege.setBackground(new Color(34,62,118));
        pnlCourse.setBackground(new Color(34,62,118));
        pnlStudent.setBackground(new Color(34,62,118));
        pnlEmployee.setBackground(new Color(34,62,118));
        sy.setVisible(false);
        sem.setVisible(false);
        cl.setVisible(false);
        st.setVisible(false);
        em.setVisible(false);
        sj.setVisible(true);
        cr.setVisible(false);
    }//GEN-LAST:event_jLabel7MouseClicked

    private void btnSchoolYearMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSchoolYearMouseEntered
        // TODO add your handling code here:
        if(pnlSchoolYear.getBackground().equals(new Color(34,62,118)))
            pnlSchoolYear.setBackground(new Color(25,42,86));
    }//GEN-LAST:event_btnSchoolYearMouseEntered

    private void btnSchoolYearMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSchoolYearMouseExited
        // TODO add your handling code here:
        if(pnlSemester.getBackground().equals(new Color(25,42,86)) 
           || pnlCollege.getBackground().equals(new Color(25,42,86))
           || pnlStudent.getBackground().equals(new Color(25,42,86))
           || pnlEmployee.getBackground().equals(new Color(25,42,86))
           || pnlSubject.getBackground().equals(new Color(25,42,86))
           || pnlCourse.getBackground().equals(new Color(25,42,86))) {
                pnlSchoolYear.setBackground(new Color(34,62,118));
        }
    }//GEN-LAST:event_btnSchoolYearMouseExited

    private void btnSemMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSemMouseEntered
        // TODO add your handling code here:
        if(pnlSemester.getBackground().equals(new Color(34,62,118)))
            pnlSemester.setBackground(new Color(25,42,86));
    }//GEN-LAST:event_btnSemMouseEntered

    private void btnSemMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSemMouseExited
        // TODO add your handling code here:
        if(pnlSchoolYear.getBackground().equals(new Color(25,42,86)) 
           || pnlCollege.getBackground().equals(new Color(25,42,86))
           || pnlStudent.getBackground().equals(new Color(25,42,86))
           || pnlEmployee.getBackground().equals(new Color(25,42,86))
           || pnlSubject.getBackground().equals(new Color(25,42,86))
           || pnlCourse.getBackground().equals(new Color(25,42,86))) {
                pnlSemester.setBackground(new Color(34,62,118));
        }
    }//GEN-LAST:event_btnSemMouseExited

    private void btnCollegeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCollegeMouseEntered
        // TODO add your handling code here:
        if(pnlCollege.getBackground().equals(new Color(34,62,118)))
            pnlCollege.setBackground(new Color(25,42,86));
    }//GEN-LAST:event_btnCollegeMouseEntered

    private void btnCollegeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCollegeMouseExited
        // TODO add your handling code here:
        if(pnlSchoolYear.getBackground().equals(new Color(25,42,86)) 
           || pnlSemester.getBackground().equals(new Color(25,42,86))
           || pnlStudent.getBackground().equals(new Color(25,42,86))
           || pnlEmployee.getBackground().equals(new Color(25,42,86))
           || pnlSubject.getBackground().equals(new Color(25,42,86))
           || pnlCourse.getBackground().equals(new Color(25,42,86))) {
                pnlCollege.setBackground(new Color(34,62,118));
        }
    }//GEN-LAST:event_btnCollegeMouseExited

    private void btnCourseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCourseMouseEntered
        // TODO add your handling code here:
        if(pnlCourse.getBackground().equals(new Color(34,62,118)))
            pnlCourse.setBackground(new Color(25,42,86));
    }//GEN-LAST:event_btnCourseMouseEntered

    private void btnCourseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCourseMouseExited
        // TODO add your handling code here:
        if(pnlSchoolYear.getBackground().equals(new Color(25,42,86)) 
           || pnlSemester.getBackground().equals(new Color(25,42,86))
           || pnlStudent.getBackground().equals(new Color(25,42,86))
           || pnlEmployee.getBackground().equals(new Color(25,42,86))
           || pnlSubject.getBackground().equals(new Color(25,42,86))
           || pnlCollege.getBackground().equals(new Color(25,42,86))) {
                pnlCourse.setBackground(new Color(34,62,118));
        }
    }//GEN-LAST:event_btnCourseMouseExited

    private void btnStudentMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnStudentMouseEntered
        // TODO add your handling code here:
        if(pnlStudent.getBackground().equals(new Color(34,62,118)))
            pnlStudent.setBackground(new Color(25,42,86));
    }//GEN-LAST:event_btnStudentMouseEntered

    private void btnStudentMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnStudentMouseExited
        // TODO add your handling code here:
        if(pnlSchoolYear.getBackground().equals(new Color(25,42,86)) 
           || pnlSemester.getBackground().equals(new Color(25,42,86))
           || pnlCourse.getBackground().equals(new Color(25,42,86))
           || pnlEmployee.getBackground().equals(new Color(25,42,86))
           || pnlSubject.getBackground().equals(new Color(25,42,86))
           || pnlCollege.getBackground().equals(new Color(25,42,86))) {
                pnlStudent.setBackground(new Color(34,62,118));
        }
    }//GEN-LAST:event_btnStudentMouseExited

    private void btnEmployeeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEmployeeMouseEntered
        // TODO add your handling code here:
        if(pnlEmployee.getBackground().equals(new Color(34,62,118)))
            pnlEmployee.setBackground(new Color(25,42,86));
    }//GEN-LAST:event_btnEmployeeMouseEntered

    private void btnEmployeeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEmployeeMouseExited
        // TODO add your handling code here:
        if(pnlSchoolYear.getBackground().equals(new Color(25,42,86)) 
           || pnlSemester.getBackground().equals(new Color(25,42,86))
           || pnlCourse.getBackground().equals(new Color(25,42,86))
           || pnlStudent.getBackground().equals(new Color(25,42,86))
           || pnlSubject.getBackground().equals(new Color(25,42,86))
           || pnlCollege.getBackground().equals(new Color(25,42,86))) {
                pnlEmployee.setBackground(new Color(34,62,118));
        }
    }//GEN-LAST:event_btnEmployeeMouseExited

    private void jLabel7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseEntered
        // TODO add your handling code here:
        if(pnlSubject.getBackground().equals(new Color(34,62,118)))
            pnlSubject.setBackground(new Color(25,42,86));
    }//GEN-LAST:event_jLabel7MouseEntered

    private void jLabel7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseExited
        // TODO add your handling code here:
        if(pnlSchoolYear.getBackground().equals(new Color(25,42,86)) 
           || pnlSemester.getBackground().equals(new Color(25,42,86))
           || pnlCourse.getBackground().equals(new Color(25,42,86))
           || pnlStudent.getBackground().equals(new Color(25,42,86))
           || pnlEmployee.getBackground().equals(new Color(25,42,86))
           || pnlCollege.getBackground().equals(new Color(25,42,86))) {
                pnlSubject.setBackground(new Color(34,62,118));
        }
    }//GEN-LAST:event_jLabel7MouseExited


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel btnCollege;
    private javax.swing.JLabel btnCourse;
    private javax.swing.JLabel btnEmployee;
    private javax.swing.JLabel btnSchoolYear;
    private javax.swing.JLabel btnSem;
    private javax.swing.JLabel btnStudent;
    private javax.swing.JLayeredPane dmTransitionCard;
    private javax.swing.JLabel jLabel7;
    private finalproject.RoundedPanel pnlCollege;
    private finalproject.RoundedPanel pnlCourse;
    private finalproject.RoundedPanel pnlEmployee;
    private finalproject.RoundedPanel pnlSchoolYear;
    private finalproject.RoundedPanel pnlSemester;
    private finalproject.RoundedPanel pnlStudent;
    private finalproject.RoundedPanel pnlSubject;
    // End of variables declaration//GEN-END:variables
}

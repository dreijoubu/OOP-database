package finalproject;

public class FinalProject {

    public static void main(String[] args) {
     Screen ms = new Screen();
       ms.setVisible(true);
    }
    
}
